[Home](../index.md) &gt; [ClientCapabilities](./clientcapabilities.md)

# Namespace ClientCapabilities

Predefined latest client capabilities

<b>Signature:</b>

```typescript
namespace ClientCapabilities 
```

## Variables

|  Variable | Description |
|  --- | --- |
|  [ALL](./clientcapabilities/variables/all.md) |  |

