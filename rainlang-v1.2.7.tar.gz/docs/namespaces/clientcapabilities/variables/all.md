[Home](../../../index.md) &gt; [ClientCapabilities](../../clientcapabilities.md) &gt; [ALL](./all.md)

# Variable ClientCapabilities.ALL

<b>Signature:</b>

```typescript
ALL: ClientCapabilities
```
