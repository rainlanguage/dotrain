[Home](../index.md) &gt; [isHexString](./ishexstring.md)

# Variable isHexString

ethers isHexString

<b>Signature:</b>

```typescript
isHexString: typeof utils.isHexString
```
