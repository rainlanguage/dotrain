[Home](../index.md) &gt; [isBigNumberish](./isbignumberish_1.md)

# Function isBigNumberish()

function to check if the a value is of type BigNumberish, from EthersJS library

<b>Signature:</b>

```typescript
function isBigNumberish(value: any): boolean;
```

## Parameters

|  Parameter | Type | Description |
|  --- | --- | --- |
|  value | `any` | the value to check |

<b>Returns:</b>

`boolean`

boolean

