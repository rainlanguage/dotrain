[Home](../index.md) &gt; [deepFreeze](./deepfreeze_1.md)

# Function deepFreeze()

Deeply freezes an object, all of the properties of propterties gets frozen

<b>Signature:</b>

```typescript
function deepFreeze(object: any): any;
```

## Parameters

|  Parameter | Type | Description |
|  --- | --- | --- |
|  object | `any` | object to freez |

<b>Returns:</b>

`any`

frozen object

