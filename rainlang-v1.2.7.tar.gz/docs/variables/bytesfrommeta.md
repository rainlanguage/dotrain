[Home](../index.md) &gt; [bytesFromMeta](./bytesfrommeta.md)

# Variable bytesFromMeta

Convert meta or array of metas or a schema to bytes and compress them for on-chain deployment

<b>Signature:</b>

```typescript
bytesFromMeta: (meta: object | object[] | string, schema: object | string) => string
```
