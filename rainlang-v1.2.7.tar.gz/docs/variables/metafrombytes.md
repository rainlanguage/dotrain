[Home](../index.md) &gt; [metaFromBytes](./metafrombytes.md)

# Variable metaFromBytes

Decompress and convert bytes to meta

<b>Signature:</b>

```typescript
metaFromBytes: (bytes: BytesLike, schema: object | string) => any
```
