[Home](../index.md) &gt; [hexZeroPad](./hexzeropad.md)

# Variable hexZeroPad

ethers hexZeroPad

<b>Signature:</b>

```typescript
hexZeroPad: typeof utils.hexZeroPad
```
