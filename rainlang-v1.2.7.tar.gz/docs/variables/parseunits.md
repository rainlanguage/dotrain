[Home](../index.md) &gt; [parseUnits](./parseunits.md)

# Variable parseUnits

ethers parseUnits

<b>Signature:</b>

```typescript
parseUnits: typeof utils.parseUnits
```
