[Home](../index.md) &gt; [concat](./concat.md)

# Variable concat

ethers concat

<b>Signature:</b>

```typescript
concat: typeof utils.concat
```
