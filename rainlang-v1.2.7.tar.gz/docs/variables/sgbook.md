[Home](../index.md) &gt; [sgBook](./sgbook.md)

# Variable sgBook

Subgraph endpoints and their chain ids as key/value pairs

<b>Signature:</b>

```typescript
sgBook: {
    [chainId: number | string]: string;
}
```
