[Home](../index.md) &gt; [paddedUInt64](./paddeduint64.md)

# Variable paddedUInt64

Utility function to produce 64 bits size hexString

<b>Signature:</b>

```typescript
paddedUInt64: (value: BigNumberish) => string
```
