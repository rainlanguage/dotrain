[Home](../index.md) &gt; [MemoryType](./memorytype.md)

# Enum MemoryType

Type for read-memory opcode

<b>Signature:</b>

```typescript
enum MemoryType 
```

## Enumeration Members

|  Member | Value | Description |
|  --- | --- | --- |
|  Constant | `1` |  |
|  Stack | `0` |  |

