[Home](../index.md) &gt; [RDAliasNode](./rdaliasnode.md)

# Type RDAliasNode

Type of RainDocument's lhs aliases

<b>Signature:</b>

```typescript
type RDAliasNode = {
    name: string;
    position: RDPosition;
    lhs?: RDAliasNode;
};
```
