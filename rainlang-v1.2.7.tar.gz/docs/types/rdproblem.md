[Home](../index.md) &gt; [RDProblem](./rdproblem.md)

# Type RDProblem

Type of RainDocument's problem (error)

<b>Signature:</b>

```typescript
type RDProblem = {
    msg: string;
    position: RDPosition;
    code: number;
};
```
