[Home](../index.md) &gt; [RDComment](./rdcomment.md)

# Type RDComment

Type of RainDocument's comments

<b>Signature:</b>

```typescript
type RDComment = {
    comment: string;
    position: RDPosition;
};
```
