'use strict';

module.exports = require('./dist/cjs/index');