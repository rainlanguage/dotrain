[Home](../index.md) &gt; [getQuery](./getquery.md)

# Variable getQuery

Get the query content

<b>Signature:</b>

```typescript
getQuery: (address: string) => string
```
