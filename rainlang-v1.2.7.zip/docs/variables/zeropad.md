[Home](../index.md) &gt; [zeroPad](./zeropad.md)

# Variable zeroPad

ethers zeroPad

<b>Signature:</b>

```typescript
zeroPad: typeof utils.zeroPad
```
