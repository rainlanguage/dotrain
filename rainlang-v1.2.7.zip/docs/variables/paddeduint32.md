[Home](../index.md) &gt; [paddedUInt32](./paddeduint32.md)

# Variable paddedUInt32

Utility function to produce 32 bits size hexString

<b>Signature:</b>

```typescript
paddedUInt32: (value: BigNumberish) => string
```
