[Home](../index.md) &gt; [validateMeta](./validatemeta.md)

# Variable validateMeta

Validate a meta or array of metas against a schema

<b>Signature:</b>

```typescript
validateMeta: (meta: object | object[] | string, schema: object | string) => boolean
```
