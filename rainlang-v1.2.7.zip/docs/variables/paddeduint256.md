[Home](../index.md) &gt; [paddedUInt256](./paddeduint256.md)

# Variable paddedUInt256

Utility function that transforms a BigNumberish from the output of the ITierV2 contract report

<b>Signature:</b>

```typescript
paddedUInt256: (report: BigNumberish) => string
```
