[Home](../index.md) &gt; [paddedUInt160](./paddeduint160.md)

# Variable paddedUInt160

Utility function that transforms a BigNumberish to an ether address (40 char length hexString)

<b>Signature:</b>

```typescript
paddedUInt160: (address: BigNumberish) => string
```
