[Home](../index.md) &gt; [paddedUInt128](./paddeduint128.md)

# Variable paddedUInt128

Utility function to produce 128 bits size hexString

<b>Signature:</b>

```typescript
paddedUInt128: (value: BigNumberish) => string
```
