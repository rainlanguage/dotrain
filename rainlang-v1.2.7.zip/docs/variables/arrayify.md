[Home](../index.md) &gt; [arrayify](./arrayify.md)

# Variable arrayify

ethers arrayify

<b>Signature:</b>

```typescript
arrayify: typeof utils.arrayify
```
