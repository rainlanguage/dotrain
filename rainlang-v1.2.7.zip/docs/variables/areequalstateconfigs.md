[Home](../index.md) &gt; [areEqualStateConfigs](./areequalstateconfigs.md)

# Variable areEqualStateConfigs

Checks 2 ExpressionConfig objects to see if they are equal or not

<b>Signature:</b>

```typescript
areEqualStateConfigs: (config1: ExpressionConfig, config2: ExpressionConfig) => boolean
```
