[Home](../index.md) &gt; [hexlify](./hexlify.md)

# Variable hexlify

ethers hexlify

<b>Signature:</b>

```typescript
hexlify: typeof utils.hexlify
```
