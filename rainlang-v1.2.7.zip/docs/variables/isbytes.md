[Home](../index.md) &gt; [isBytes](./isbytes.md)

# Variable isBytes

ethers isBytes

<b>Signature:</b>

```typescript
isBytes: typeof utils.isBytes
```
