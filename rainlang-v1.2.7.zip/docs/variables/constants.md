[Home](../index.md) &gt; [CONSTANTS](./constants.md)

# Variable CONSTANTS

ethers constants

<b>Signature:</b>

```typescript
CONSTANTS: typeof ethers.constants
```
