[Home](../index.md) &gt; [isBytesLike](./isbyteslike.md)

# Variable isBytesLike

ethers isBytesLike

<b>Signature:</b>

```typescript
isBytesLike: typeof utils.isBytesLike
```
