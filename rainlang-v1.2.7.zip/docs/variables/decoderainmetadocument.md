[Home](../index.md) &gt; [decodeRainMetaDocument](./decoderainmetadocument.md)

# Variable decodeRainMetaDocument

Use a given `dataEncoded_` as hex string and decoded it following the Rain enconding design.

<b>Signature:</b>

```typescript
decodeRainMetaDocument: (dataEncoded_: string) => Array<any>
```
