[Home](../index.md) &gt; [InputMeta](./inputmeta.md)

# Type InputMeta

Data type of opcode's inputs that determines the number of inputs an opcode has and provide information about them

<b>Signature:</b>

```typescript
type InputMeta = 0 | InputArgs;
```
