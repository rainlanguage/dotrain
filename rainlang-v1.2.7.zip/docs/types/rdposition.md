[Home](../index.md) &gt; [RDPosition](./rdposition.md)

# Type RDPosition

Type of position start and end indexes for RainDocument, inclusive at both ends

<b>Signature:</b>

```typescript
type RDPosition = [number, number];
```
