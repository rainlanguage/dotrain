[Home](../index.md) &gt; [ComputedOutput](./computedoutput.md)

# Type ComputedOutput

Data type for computed output

<b>Signature:</b>

```typescript
type ComputedOutput = {
    bits: [number, number];
    computation?: string;
};
```
