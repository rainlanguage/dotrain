[Home](../index.md) &gt; [RDNode](./rdnode.md)

# Type RDNode

Type of RainDocument's prase node

<b>Signature:</b>

```typescript
type RDNode = RDValueNode | RDOpNode | RDAliasNode;
```
