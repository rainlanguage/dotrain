[Home](../index.md) &gt; [OperandMeta](./operandmeta.md)

# Type OperandMeta

Data type of operand arguments, used only for non-constant operands

<b>Signature:</b>

```typescript
type OperandMeta = 0 | OperandArgs;
```
