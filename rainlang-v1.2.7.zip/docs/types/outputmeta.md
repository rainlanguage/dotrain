[Home](../index.md) &gt; [OutputMeta](./outputmeta.md)

# Type OutputMeta

Data type of opcode's outputs that determines the number of outputs an opcode has and provide information about them

<b>Signature:</b>

```typescript
type OutputMeta = number | ComputedOutput;
```
