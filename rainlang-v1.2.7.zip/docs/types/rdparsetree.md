[Home](../index.md) &gt; [RDParseTree](./rdparsetree.md)

# Type RDParseTree

Type of a RainDocument parse tree object

<b>Signature:</b>

```typescript
type RDParseTree = {
    tree: RDNode[];
    position: RDPosition;
}[];
```
